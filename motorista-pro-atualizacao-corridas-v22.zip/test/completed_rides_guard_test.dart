import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('uma oferta apenas visualizada não vira corrida concluída', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();

    expect(store, contains('val fare = detectedFare ?: return false'));
    expect(store, contains('put("distance", distance)'));
  });

  test('separa oferta mostrada da corrida realmente aceita', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();

    expect(store, contains('CANDIDATE_DISTANCE'));
    expect(store, contains('fun acceptLatestOffer'));
    expect(store, contains('val activePlatform = prefs.getString(ACTIVE_PLATFORM, null) ?: return false'));
  });

  test('o leitor esquece a plataforma ao sair do aplicativo de corrida', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, contains('currentPlatform = null'));
    expect(service, contains('activePlatform = null'));
  });
}
