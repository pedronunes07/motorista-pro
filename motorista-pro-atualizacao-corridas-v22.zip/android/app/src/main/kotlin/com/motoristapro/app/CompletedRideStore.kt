package com.motoristapro.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object CompletedRideStore {
    private const val PREFS = "completed_rides_native"
    private const val ACTIVE_PLATFORM = "active_platform"
    private const val ACTIVE_FARE = "active_fare"
    private const val ACTIVE_DISTANCE = "active_distance"
    private const val ACTIVE_AT = "active_at"
    private const val CANDIDATE_PLATFORM = "candidate_platform"
    private const val CANDIDATE_FARE = "candidate_fare"
    private const val CANDIDATE_DISTANCE = "candidate_distance"
    private const val CANDIDATE_AT = "candidate_at"
    private const val PENDING = "pending"
    private var lastCompletionAt = 0L

    fun rememberOffer(context: Context, platform: String, fare: Double, distance: Double) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(CANDIDATE_PLATFORM, platform)
            .putFloat(CANDIDATE_FARE, fare.toFloat())
            .putFloat(CANDIDATE_DISTANCE, distance.toFloat())
            .putLong(CANDIDATE_AT, System.currentTimeMillis())
            .apply()
    }

    fun acceptLatestOffer(context: Context, platform: String): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val candidateAt = prefs.getLong(CANDIDATE_AT, 0L)
        if (candidateAt <= 0L || System.currentTimeMillis() - candidateAt > 2 * 60 * 1000L) return false
        if (prefs.getString(CANDIDATE_PLATFORM, null) != platform) return false
        val fare = prefs.getFloat(CANDIDATE_FARE, 0f)
        val distance = prefs.getFloat(CANDIDATE_DISTANCE, 0f)
        if (fare <= 0f || distance <= 0f) return false
        prefs.edit()
            .putString(ACTIVE_PLATFORM, platform)
            .putFloat(ACTIVE_FARE, fare)
            .putFloat(ACTIVE_DISTANCE, distance)
            .putLong(ACTIVE_AT, System.currentTimeMillis())
            .apply()
        return true
    }

    fun complete(context: Context, detectedPlatform: String?, detectedFare: Double?): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastCompletionAt < 20000) return false
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val rememberedAt = prefs.getLong(ACTIVE_AT, 0L)
        if (rememberedAt <= 0L || now - rememberedAt > 6 * 60 * 60 * 1000L) return false
        val activePlatform = prefs.getString(ACTIVE_PLATFORM, null) ?: return false
        if (detectedPlatform != null && detectedPlatform != activePlatform) return false
        val platform = activePlatform
        val fare = detectedFare ?: return false
        val distance = prefs.getFloat(ACTIVE_DISTANCE, 0f).toDouble()
        if (fare <= 0 || distance <= 0) return false
        val pending = try { JSONArray(prefs.getString(PENDING, "[]")) } catch (_: Throwable) { JSONArray() }
        pending.put(JSONObject().put("id", "$platform-$now").put("platform", platform).put("value", fare).put("distance", distance).put("timestamp", now))
        prefs.edit().putString(PENDING, pending.toString())
            .remove(ACTIVE_PLATFORM).remove(ACTIVE_FARE).remove(ACTIVE_DISTANCE).remove(ACTIVE_AT)
            .apply()
        lastCompletionAt = now
        RideOverlay.remove(context)
        return true
    }

    fun drain(context: Context): List<Map<String, Any>> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = try { JSONArray(prefs.getString(PENDING, "[]")) } catch (_: Throwable) { JSONArray() }
        val result = mutableListOf<Map<String, Any>>()
        for (index in 0 until array.length()) {
            val item = array.getJSONObject(index)
            result.add(mapOf("id" to item.getString("id"), "platform" to item.getString("platform"), "value" to item.getDouble("value"), "distance" to item.optDouble("distance", 0.0), "timestamp" to item.getLong("timestamp")))
        }
        prefs.edit().remove(PENDING).apply()
        return result
    }
}
