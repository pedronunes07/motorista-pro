package com.motoristapro.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object CompletedRideStore {
    private const val PREFS = "completed_rides_native"
    private const val ACTIVE_PLATFORM = "active_platform"
    private const val ACTIVE_FARE = "active_fare"
    private const val PENDING = "pending"
    private var lastCompletionAt = 0L

    fun rememberOffer(context: Context, platform: String, fare: Double) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(ACTIVE_PLATFORM, platform).putFloat(ACTIVE_FARE, fare.toFloat()).apply()
    }

    fun complete(context: Context, detectedPlatform: String?, detectedFare: Double?): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastCompletionAt < 20000) return false
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val platform = detectedPlatform ?: prefs.getString(ACTIVE_PLATFORM, null) ?: return false
        val fare = detectedFare ?: prefs.getFloat(ACTIVE_FARE, 0f).toDouble()
        if (fare <= 0) return false
        val pending = try { JSONArray(prefs.getString(PENDING, "[]")) } catch (_: Throwable) { JSONArray() }
        pending.put(JSONObject().put("id", "$platform-$now").put("platform", platform).put("value", fare).put("timestamp", now))
        prefs.edit().putString(PENDING, pending.toString()).remove(ACTIVE_PLATFORM).remove(ACTIVE_FARE).apply()
        lastCompletionAt = now
        RideOverlay.remove(context)
        return true
    }

    fun drain(context: Context): List<Map<String, Any>> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = try { JSONArray(prefs.getString(PENDING, "[]")) } catch (_: Throwable) { JSONArray() }
        val result = mutableListOf<Map<String, Any>>()
        for (index in 0 until array.length()) {
            val item = array.getJSONObject(index)
            result.add(mapOf("id" to item.getString("id"), "platform" to item.getString("platform"), "value" to item.getDouble("value"), "timestamp" to item.getLong("timestamp")))
        }
        prefs.edit().remove(PENDING).apply()
        return result
    }
}
