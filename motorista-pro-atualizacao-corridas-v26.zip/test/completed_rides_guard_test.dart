import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('uma oferta apenas visualizada não vira corrida concluída', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();

    expect(store, contains('val fare = detectedFare ?: return false'));
    expect(store, contains('put("distance", distance)'));
  });

  test('separa oferta mostrada da corrida realmente aceita', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();

    expect(store, contains('CANDIDATE_DISTANCE'));
    expect(store, contains('fun acceptLatestOffer'));
    // A v26 também aceita um comprovante final completo quando o toque em
    // Aceitar não foi detectado. A proteção é não usar preço ou distância
    // da oferta candidata para preencher uma conclusão incompleta.
    final completionStart = store.indexOf('    fun complete(');
    final completionEnd = store.indexOf('    fun drain(', completionStart);
    expect(completionStart, greaterThanOrEqualTo(0));
    expect(completionEnd, greaterThan(completionStart));
    final completion = store.substring(completionStart, completionEnd);

    expect(completion, isNot(contains('getFloat(CANDIDATE_FARE')));
    expect(completion, isNot(contains('getFloat(CANDIDATE_DISTANCE')));
    expect(completion, contains('val fare = detectedFare ?: return false'));
    expect(completion, contains('takeIf { hasActiveRide && it > 0 }'));
    expect(completion, contains('?: rememberedDistance ?: return false'));
  });

  test('o leitor esquece a plataforma ao sair do aplicativo de corrida', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, contains('currentPlatform = null'));
    expect(service, contains('activePlatform = null'));
  });

  test('confirma aceitação pela tela de corrida quando a 99 oculta o toque', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(store, contains('fun confirmRideStarted'));
    expect(service, contains('ScreenOfferParser.isActiveRide'));
    expect(service, contains('CompletedRideStore.confirmRideStarted'));
  });

  test('encerramento ou cancelamento não vira corrida concluída', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, isNot(contains('"corrida encerrada", "viagem finalizada"')));
    expect(service, contains('completionMoney.find(text)'));
    expect(service, contains('CompletedRideStore.discardCandidate'));
  });

  test('captura contínua confirma início e conclusão mesmo sem evento da 99', () {
    final capture = File(
      'android/app/src/main/kotlin/com/motoristapro/app/ScreenCaptureService.kt',
    ).readAsStringSync();

    expect(capture, contains('ScreenOfferParser.detectPlatform'));
    expect(capture, contains('ScreenOfferParser.isActiveRide(result.text)'));
    expect(capture, contains('CompletedRideStore.confirmRideStarted'));
    expect(capture, contains('CompletedRideStore.complete'));
  });

  test('próxima oferta não substitui valores da corrida em andamento', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();

    expect(store, contains('NEXT_PLATFORM'));
    expect(store, contains('A 99 pode oferecer a próxima corrida'));
    expect(store, contains('putString(ACTIVE_PLATFORM, prefs.getString(NEXT_PLATFORM, null))'));
  });

  test('comprovante final completo salva mesmo se a 99 ocultou a aceitação', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();

    expect(service, contains('fun completionDistance'));
    expect(store, contains('detectedDistance: Double? = null'));
    expect(store, contains('val distance = detectedDistance?.takeIf'));
    expect(store, contains('?: rememberedDistance ?: return false'));
  });

  test('ocr analisa a região do cartão antes da tela inteira', () {
    final capture = File(
      'android/app/src/main/kotlin/com/motoristapro/app/ScreenCaptureService.kt',
    ).readAsStringSync();

    expect(capture, contains('result.textBlocks.filter'));
    expect(capture, contains('ScreenOfferParser.parse(cardText)'));
  });
}
