package com.motoristapro.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.Executors

class RideAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var isRunning = false
        @Volatile var currentPlatform: String? = null
    }

    private var lastScanAt = 0L
    private var scanning = false
    private var activePlatform: String? = null
    private var activePlatformAt = 0L
    private var scanUntil = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scanLoop = object : Runnable {
        override fun run() {
            val platform = activePlatform ?: return
            if (System.currentTimeMillis() > scanUntil) return
            scanCurrentWindow(platform)
            mainHandler.postDelayed(this, 1800)
        }
    }

    private fun scanCurrentWindow(platform: String) {
        val root = rootInActiveWindow
        if (root != null) {
            val chunks = mutableListOf<String>()
            collectText(root, chunks)
            val visibleText = chunks.distinct().joinToString(" | ")
            ScreenOfferParser.completionFare(visibleText)?.let { CompletedRideStore.complete(this, platform, it) }
            // A lista de espera pode conter várias ofertas. Procure primeiro
            // dentro de cada cartão para não misturar valores de corridas
            // diferentes; use a tela inteira apenas como alternativa.
            val offer = findOfferInTree(root) ?: ScreenOfferParser.parse(visibleText)
            if (offer != null) {
                showOffer(platform, offer)
                return
            }
        }
        scanScreenshot(platform)
    }
    private val screenshotExecutor = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onServiceConnected() { isRunning = true }
    override fun onUnbind(intent: android.content.Intent?): Boolean { isRunning = false; return super.onUnbind(intent) }
    override fun onInterrupt() = Unit

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = (event?.packageName?.toString()
            ?: rootInActiveWindow?.packageName?.toString())?.lowercase(Locale.ROOT) ?: return
        val platform = when {
            packageName.contains("uber") -> "Uber"
            packageName.contains("taxis99") || packageName.contains("99") || packageName.contains("didi") -> "99"
            packageName.contains("indriver") || packageName.contains("indrive") -> "inDrive"
            else -> {
                // Samsung/Android envia eventos do System UI, da permissão de
                // sobreposição e do próprio cartão enquanto a 99 continua em
                // primeiro plano. Não descarte a corrida por causa desses
                // eventos intermediários.
                if (System.currentTimeMillis() - activePlatformAt > 15 * 60 * 1000L) {
                    activePlatform = null
                    currentPlatform = null
                    scanUntil = 0L
                    mainHandler.removeCallbacks(scanLoop)
                }
                return
            }
        }
        activePlatform = platform
        activePlatformAt = System.currentTimeMillis()
        currentPlatform = platform
        scanUntil = Long.MAX_VALUE
        mainHandler.removeCallbacks(scanLoop)
        mainHandler.post(scanLoop)
        if (event?.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            // Primeiro tenta ler o conteúdo ainda presente no evento do toque;
            // depois relê a janela durante a animação da oferta da 99.
            event.source?.let { source ->
                val clickedChunks = mutableListOf<String>()
                collectText(source, clickedChunks)
                val clickedText = clickedChunks.joinToString(" | ").lowercase(Locale.ROOT)
                if (clickedText.contains("aceitar") || clickedText.contains("aceite")) {
                    // Vincule a corrida aceita aos valores do cartão tocado,
                    // nunca a outra oferta que esteja visível na fila.
                    findOfferAround(source)?.let { accepted ->
                        CompletedRideStore.rememberOffer(this, platform, accepted.fare, accepted.distance)
                        showOffer(platform, accepted)
                    }
                    CompletedRideStore.acceptLatestOffer(this, platform)
                }
                ScreenOfferParser.parse(clickedChunks.joinToString(" | "))?.let { showOffer(platform, it) }
            }
            mainHandler.postDelayed({ scanCurrentWindow(platform) }, 250)
            mainHandler.postDelayed({ scanCurrentWindow(platform) }, 700)
            mainHandler.postDelayed({ scanCurrentWindow(platform) }, 1500)
        }
        val root = rootInActiveWindow ?: event?.source ?: return
        val chunks = mutableListOf<String>()
        collectText(root, chunks)
        val text = chunks.distinct().joinToString(" | ")
        ScreenOfferParser.completionFare(text)?.let { CompletedRideStore.complete(this, platform, it) }
        val offer = findOfferInTree(root) ?: ScreenOfferParser.parse(text)
        if (offer == null) {
            scanScreenshot(platform)
            return
        }
        showOffer(platform, offer)
    }

    private fun scanScreenshot(platform: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || scanning) return
        val now = System.currentTimeMillis()
        if (now - lastScanAt < 900) return
        lastScanAt = now
        scanning = true
        takeScreenshot(Display.DEFAULT_DISPLAY, screenshotExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val bitmap = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                result.hardwareBuffer.close()
                if (bitmap == null) { scanning = false; return }
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { recognized ->
                        ScreenOfferParser.completionFare(recognized.text)?.let { CompletedRideStore.complete(this@RideAccessibilityService, platform, it) }
                        ScreenOfferParser.parse(recognized.text)?.let { showOffer(platform, it) }
                    }
                    .addOnCompleteListener { bitmap.recycle(); scanning = false }
            }
            override fun onFailure(errorCode: Int) { scanning = false }
        })
    }

    private fun showOffer(platform: String, offer: ScreenOffer) {
        CompletedRideStore.rememberOffer(this, platform, offer.fare, offer.distance)
        val preferences = getSharedPreferences("ride_calculator", MODE_PRIVATE)
        RideOverlay.show(this, mapOf(
            "platform" to platform,
            "fare" to offer.fare,
            "distance" to offer.distance,
            "minutes" to offer.minutes,
            "perKm" to offer.fare / offer.distance,
            "perHour" to offer.fare * 60.0 / offer.minutes,
            "yellow" to preferences.getFloat("yellow", 1.5f).toDouble(),
            "green" to preferences.getFloat("green", 2.0f).toDouble(),
            "rating" to offer.rating,
            "ratingMinimum" to preferences.getFloat("ratingMinimum", 4.8f).toDouble(),
            "theme" to preferences.getInt("theme",0), "fontScale" to preferences.getFloat("fontScale",1f).toDouble(), "cardScale" to preferences.getFloat("cardScale",1f).toDouble()
        ))
    }

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacks(scanLoop)
        recognizer.close()
        screenshotExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        for (index in 0 until node.childCount) node.getChild(index)?.let { collectText(it, out) }
    }

    private fun findOfferInTree(node: AccessibilityNodeInfo): ScreenOffer? {
        val chunks = mutableListOf<String>()
        collectText(node, chunks)
        ScreenOfferParser.parse(chunks.distinct().joinToString(" | "))?.let { return it }
        for (index in 0 until node.childCount) {
            node.getChild(index)?.let { child ->
                findOfferInTree(child)?.let { return it }
            }
        }
        return null
    }

    private fun findOfferAround(source: AccessibilityNodeInfo): ScreenOffer? {
        var node: AccessibilityNodeInfo? = source
        repeat(6) {
            val current = node ?: return null
            val chunks = mutableListOf<String>()
            collectText(current, chunks)
            ScreenOfferParser.parse(chunks.distinct().joinToString(" | "))?.let { return it }
            node = current.parent
        }
        return null
    }
}

data class ScreenOffer(val fare: Double, val distance: Double, val minutes: Int, val rating: Double?)

object ScreenOfferParser {
    private val money = Regex("R\\$\\s*([0-9]{1,3}(?:[.]?[0-9]{3})*(?:[,][0-9]{1,2})?|[0-9]+(?:[.][0-9]{1,2})?)", RegexOption.IGNORE_CASE)
    private val km = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*km", RegexOption.IGNORE_CASE)
    private val min = Regex("([0-9]+)\\s*(?:min|minutos?|m)(?![a-z])", RegexOption.IGNORE_CASE)
    private val hourMinute = Regex("([0-9]+)\\s*h(?:ora)?s?\\s*([0-9]+)\\s*m", RegexOption.IGNORE_CASE)
    private val labeledRating = Regex("(?:★|⭐|nota)\\s*[: -]?\\s*([3-5](?:[.,][0-9]{1,2})?)", RegexOption.IGNORE_CASE)
    private val ridesRating = Regex("([3-5][.,][0-9]{1,2})\\s*(?:[·•|]\\s*)?(?:\\(\\s*)?[0-9]+\\s*(?:\\)|corridas|viagens)", RegexOption.IGNORE_CASE)
    private val completionMoney = Regex("(?:valor\\s+(?:recebido|da corrida)|total\\s+recebido|você\\s+ganhou|voce\\s+ganhou|ganho\\s+da corrida|receber\\s+em dinheiro|cobrar\\s+do passageiro)[^R$]{0,50}R\\$\\s*([0-9]{1,3}(?:[.]?[0-9]{3})*(?:[,][0-9]{1,2})?|[0-9]+(?:[.][0-9]{1,2})?)", RegexOption.IGNORE_CASE)

    fun parse(text: String): ScreenOffer? {
        // A captura também enxerga o cartão do próprio Motorista Pro. Sem este
        // filtro, R$/km e R$/h do cartão eram lidos como se fossem uma nova
        // corrida e os valores aumentavam a cada leitura.
        val offerText = text.replace(" | ", "\n").lineSequence().filterNot { line ->
            val normalized = line.lowercase()
            normalized.contains("acima da meta") ||
                normalized.contains("abaixo da meta") ||
                normalized.contains("faixa intermedi") ||
                normalized.contains("/km") ||
                normalized.contains("/h") ||
                normalized.contains("motorista pro ativo")
        }.joinToString("\n")
        val normalizedOffer = offerText.lowercase()
        if (isCompletion(offerText)) return null
        if (listOf("aceitar", "selecionar", "aceite", "recusar", "oferta", "solicitação", "solicitacao", "nova corrida", "chamada").none(normalizedOffer::contains)) return null
        val fares = money.findAll(offerText).mapNotNull { decimal(it.groupValues[1]) }.filter { it in 3.0..999.0 }.distinct().toList()
        if (fares.size != 1) return null
        val fare = fares.single()
        val distances = km.findAll(offerText).mapNotNull { decimal(it.groupValues[1]) }.filter { it in 0.1..500.0 }.distinct().toList()
        if (distances.isEmpty()) return null
        val hasRouteParts = listOf("embarque", "buscar", "passageiro", "destino", "viagem").any(normalizedOffer::contains)
        // A tela atual da 99 mostra dois blocos (tempo/distância até o
        // passageiro e tempo/distância da viagem), mas não escreve os rótulos
        // "embarque" e "destino". O botão Aceitar identifica a oferta; some
        // os dois trechos reais exibidos em vez de rejeitar o cartão.
        val isTwoPartOffer = distances.size == 2 && normalizedOffer.contains("aceitar")
        val distance = when {
            distances.size == 1 -> distances.single()
            distances.size == 2 && (hasRouteParts || isTwoPartOffer) -> distances.sum()
            else -> return null
        }
        val durationValues = min.findAll(offerText).mapNotNull { it.groupValues[1].toIntOrNull() }.filter { it in 1..600 }.distinct().toList()
        val hourValue = hourMinute.find(offerText)?.let {
            (it.groupValues[1].toIntOrNull() ?: 0) * 60 + (it.groupValues[2].toIntOrNull() ?: 0)
        }
        val minutes = hourValue?.takeIf { it > 0 } ?: when {
            durationValues.size == 1 -> durationValues.single()
            durationValues.size == 2 && (hasRouteParts || isTwoPartOffer) -> durationValues.sum()
            else -> return null
        }
        val rating = (labeledRating.find(offerText) ?: ridesRating.find(offerText))?.groupValues?.get(1)?.let(::decimal)?.takeIf { it in 1.0..5.0 }
        return ScreenOffer(fare, distance, minutes, rating)
    }

    private fun isCompletion(text: String): Boolean {
        val normalized = text.lowercase()
        return listOf("corrida finalizada", "corrida concluída", "corrida concluida", "corrida encerrada", "viagem finalizada", "viagem concluída", "viagem concluida", "viagem encerrada", "finalizada com sucesso", "você ganhou", "voce ganhou", "total recebido").any(normalized::contains)
    }

    fun completionFare(text: String): Double? {
        if (!isCompletion(text)) return null
        completionMoney.find(text)?.groupValues?.get(1)?.let(::decimal)?.takeIf { it in 3.0..999.0 }?.let { return it }
        return null
    }

    private fun decimal(value: String): Double? {
        val normalized = if (value.contains(',')) value.replace(".", "").replace(',', '.') else value
        return normalized.toDoubleOrNull()
    }
}
