import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('uma oferta apenas visualizada não vira corrida concluída', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();

    expect(store, contains('val fare = detectedFare ?: return false'));
    expect(store, contains('put("distance", distance)'));
  });

  test('separa oferta mostrada da corrida realmente aceita', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();

    expect(store, contains('CANDIDATE_DISTANCE'));
    expect(store, contains('fun acceptLatestOffer'));
    expect(store, contains('val activePlatform = prefs.getString(ACTIVE_PLATFORM, null) ?: return false'));
  });

  test('o leitor esquece a plataforma ao sair do aplicativo de corrida', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, contains('currentPlatform = null'));
    expect(service, contains('activePlatform = null'));
  });

  test('confirma aceitação pela tela de corrida quando a 99 oculta o toque', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(store, contains('fun confirmRideStarted'));
    expect(service, contains('ScreenOfferParser.isActiveRide'));
    expect(service, contains('CompletedRideStore.confirmRideStarted'));
  });

  test('encerramento ou cancelamento não vira corrida concluída', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, isNot(contains('"corrida encerrada", "viagem finalizada"')));
    expect(service, contains('completionMoney.find(text)'));
    expect(service, contains('CompletedRideStore.discardCandidate'));
  });

  test('captura contínua confirma início e conclusão mesmo sem evento da 99', () {
    final capture = File(
      'android/app/src/main/kotlin/com/motoristapro/app/ScreenCaptureService.kt',
    ).readAsStringSync();

    expect(capture, contains('ScreenOfferParser.detectPlatform'));
    expect(capture, contains('ScreenOfferParser.isActiveRide(result.text)'));
    expect(capture, contains('CompletedRideStore.confirmRideStarted'));
    expect(capture, contains('CompletedRideStore.complete'));
  });

  test('próxima oferta não substitui valores da corrida em andamento', () {
    final store = File(
      'android/app/src/main/kotlin/com/motoristapro/app/CompletedRideStore.kt',
    ).readAsStringSync();

    expect(store, contains('NEXT_PLATFORM'));
    expect(store, contains('A 99 pode oferecer a próxima corrida'));
    expect(store, contains('putString(ACTIVE_PLATFORM, prefs.getString(NEXT_PLATFORM, null))'));
  });
}
