import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('cartão iniciado pela acessibilidade usa sobreposição compatível com a 99', () {
    final overlay = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideOverlay.kt',
    ).readAsStringSync();

    expect(overlay, contains('TYPE_ACCESSIBILITY_OVERLAY'));
    expect(overlay, contains('context is AccessibilityService'));
  });

  test('eventos do Android não apagam imediatamente a oferta ativa da 99', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, contains('activePlatformAt'));
    expect(service, contains('15 * 60 * 1000L'));
    expect(service, contains('postDelayed({ scanCurrentWindow(platform) }, 1500)'));
  });

  test('soma os dois trechos reais exibidos pela tela atual da 99', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, contains('val isTwoPartOffer = distances.size == 2'));
    expect(
      service,
      contains('distances.size == 2 && (hasRouteParts || isTwoPartOffer)'),
    );
    expect(
      service,
      contains('durationValues.size == 2 && (hasRouteParts || isTwoPartOffer)'),
    );
  });

  test('procura ofertas separadamente e mantém o cartão durante a corrida', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();
    final overlay = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideOverlay.kt',
    ).readAsStringSync();

    expect(service, contains('findOfferInTree(root)'));
    expect(service, contains('findOfferAround(source)'));
    expect(service, contains('acceptLatestOffer'));
    expect(service, isNot(contains('now - lastShownAt < 30000')));
    expect(overlay, isNot(contains('postDelayed({ if (generation == currentGeneration)')));
  });

  test('reconhece textos de conclusão atuais sem inventar o valor', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, contains('total recebido'));
    expect(service, isNot(contains('"valor da corrida", "ganho da corrida"')));
    expect(service, contains('completionMoney.find(text)'));
  });

  test('captura não bloqueia nova oferta durante corrida ativa', () {
    final capture = File(
      'android/app/src/main/kotlin/com/motoristapro/app/ScreenCaptureService.kt',
    ).readAsStringSync();

    expect(capture, isNot(contains('now - lastShown < 30000')));
    expect(capture, isNot(contains('if (offer == null) RideOverlay.reportOfferMissing(this)')));
  });

  test('fecha cartão quando a oferta some, é aceita ou recusada', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();
    final overlay = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideOverlay.kt',
    ).readAsStringSync();

    expect(service, contains('RideOverlay.reportOfferMissing(this)'));
    expect(service, contains('RideOverlay.dismissCurrent(this)'));
    expect(service, contains('"recusar", "rejeitar"'));
    expect(overlay, contains('fun reportOfferMissing'));
    expect(overlay, contains('dismissedOfferId'));
    expect(overlay, contains('2500L'));
  });

  test('aceita formatos de oferta sem depender de uma única legenda', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, contains('val hasOfferAction'));
    expect(service, contains('val isActiveRideScreen'));
    expect(
      service,
      isNot(contains('none(normalizedOffer::contains)) return null')),
    );
  });
}
