package com.motoristapro.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenCaptureService : Service() {
    companion object { @Volatile var isRunning = false }

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var scanning = false
    private var lastScan = 0L
    private var lastSignature = ""
    private var lastShown = 0L
    private lateinit var worker: HandlerThread
    private lateinit var handler: Handler

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "ride_capture") else Notification.Builder(this)
        val notification = builder
            .setSmallIcon(applicationInfo.icon)
            .setContentTitle("Motorista Pro ativo")
            .setContentText("Lendo ofertas da 99 e Uber")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(92, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(92, notification)

        if (!::worker.isInitialized) {
            worker = HandlerThread("ride-screen-capture").also { it.start() }
            handler = Handler(worker.looper)
        }
        if (projection == null) {
            val code = intent?.getIntExtra("resultCode", 0) ?: 0
            @Suppress("DEPRECATION")
            val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("resultData", Intent::class.java)
                else intent?.getParcelableExtra("resultData")
            if (code == 0 || data == null) { stopSelf(); return START_NOT_STICKY }
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, handler)
            startReader()
        }
        isRunning = true
        return START_NOT_STICKY
    }

    private fun startReader() {
        val metrics = resources.displayMetrics
        reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        projection?.createVirtualDisplay(
            "MotoristaProCapture", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, handler
        )
        reader?.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (scanning || now - lastScan < 1200) { image.close(); return@setOnImageAvailableListener }
            lastScan = now
            val plane = image.planes[0]
            val width = image.width
            val height = image.height
            val rowPadding = plane.rowStride - plane.pixelStride * width
            val bitmap = Bitmap.createBitmap(width + rowPadding / plane.pixelStride, height, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(plane.buffer)
            image.close()
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)
            bitmap.recycle()
            scanning = true
            recognizer.process(InputImage.fromBitmap(cropped, 0))
                .addOnSuccessListener { result -> ScreenOfferParser.parse(result.text)?.let(::showOffer) }
                .addOnCompleteListener { cropped.recycle(); scanning = false }
        }, handler)
    }

    private fun showOffer(offer: ScreenOffer) {
        val signature = "${offer.fare}:${offer.distance}:${offer.minutes}:${offer.rating}"
        val now = System.currentTimeMillis()
        if (signature == lastSignature && now - lastShown < 12000) return
        lastSignature = signature
        lastShown = now
        val prefs = getSharedPreferences("ride_calculator", MODE_PRIVATE)
        RideOverlay.show(this, mapOf(
            "platform" to (RideAccessibilityService.currentPlatform ?: "99/Uber"),
            "fare" to offer.fare, "distance" to offer.distance, "minutes" to offer.minutes,
            "perKm" to offer.fare / offer.distance, "perHour" to offer.fare * 60.0 / offer.minutes,
            "rating" to offer.rating,
            "yellow" to prefs.getFloat("yellow", 1.5f).toDouble(),
            "green" to prefs.getFloat("green", 2.0f).toDouble(),
            "ratingMinimum" to prefs.getFloat("ratingMinimum", 4.8f).toDouble()
        ))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("ride_capture", "Calculadora automática", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        isRunning = false
        reader?.close()
        projection?.stop()
        recognizer.close()
        if (::worker.isInitialized) worker.quitSafely()
        super.onDestroy()
    }
}
