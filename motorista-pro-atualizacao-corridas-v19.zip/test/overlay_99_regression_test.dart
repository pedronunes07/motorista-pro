import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('cartão iniciado pela acessibilidade usa sobreposição compatível com a 99', () {
    final overlay = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideOverlay.kt',
    ).readAsStringSync();

    expect(overlay, contains('TYPE_ACCESSIBILITY_OVERLAY'));
    expect(overlay, contains('context is AccessibilityService'));
  });

  test('eventos do Android não apagam imediatamente a oferta ativa da 99', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, contains('activePlatformAt'));
    expect(service, contains('15 * 60 * 1000L'));
    expect(service, contains('postDelayed({ scanCurrentWindow(platform) }, 1500)'));
  });

  test('soma os dois trechos reais exibidos pela tela atual da 99', () {
    final service = File(
      'android/app/src/main/kotlin/com/motoristapro/app/RideAccessibilityService.kt',
    ).readAsStringSync();

    expect(service, contains('val isTwoPartOffer = distances.size == 2'));
    expect(
      service,
      contains('distances.size == 2 && (hasRouteParts || isTwoPartOffer)'),
    );
    expect(
      service,
      contains('durationValues.size == 2 && (hasRouteParts || isTwoPartOffer)'),
    );
  });
}
